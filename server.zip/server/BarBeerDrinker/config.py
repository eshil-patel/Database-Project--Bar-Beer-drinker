database_uri= "mysql+pymysql://admin:admin123456@databaseproject336.cjt0aksn8rbx.us-east-2.rds.amazonaws.com:3306/DrinkingProject"
