from sqlalchemy import create_engine
from sqlalchemy import sql

from BarBeerDrinker import config

import logging

import datetime
from datetime import date

engine = create_engine(config.database_uri)

def get_bars():
    with engine.connect() as con:
        rs = con.execute("SELECT barId, barName, license, city, phone, address, state FROM bars;")
        return [dict(row) for row in rs]

def get_items(itemId):
    with engine.connect() as con:
        query = sql.text(
            'SELECT itemName,itemId FROM items where itemId=:itemId;'
        )

        rs = con.execute(query, itemId=itemId)
        result = rs.first()
        if result is None:
            return None
        return dict(result)

def find_bar(barId):
    with engine.connect() as con:
        query = sql.text(
            "SELECT barId, barName,license, city, phone,address, state FROM bars WHERE barId= :barId;"
        )

        rs = con.execute(query, barId=barId)
        result = rs.first()
        if result is None:
            return None
        return dict(result)
        
def find_top_drinkers(barId):
    with engine.connect() as con:
        query = sql.text('SELECT drinkerId, sum(price) AS spent from transactions WHERE barId = :barId GROUP BY drinkerId ORDER BY spent DESC LIMIT 15;')
        rs = con.execute(query, barId=barId)
        results = [dict(row) for row in rs]
        return results

def find_top_purchases(barId):
    with engine.connect() as con:
        query = sql.text('Select itemId, count(*) as purchases from transactions where barId = :barId group by itemId order by purchases desc LIMIT 15;')
        rs = con.execute(query, barId=barId)
        results = [dict(row) for row in rs]
        return results

def find_top_manufacturers(barId):
    with engine.connect() as con:
        query = sql.text('Select manufacturer, count(*) as amtspent from (Select t.itemId, i.manufacturer from transactions as t, items as i where t.barId = :barId and i.itemId = t.itemId and i.manufacturer != "") AS t GROUP BY manufacturer ORDER BY amtspent DESC;')
        rs = con.execute(query, barId=barId)
        results = [dict(row) for row in rs]
        return results

def getResults(query):
         with engine.connect() as con:
                 statement = sql.text(query)
                 rs = con.execute(statement, query=query)
                 results = [dict(row) for row in rs]
                 return results

def find_sale_dates(barId):
    with engine.connect() as con:
        query = sql.text('SELECT date FROM bills b where EXISTS(Select * From transactions t where t.barId = :barId && t.billId = b.billId);')
        rs = con.execute(query, barId=barId)
        results = [dict(row) for row in rs]
        for r in results:
            text = r['date']
            month = int(text[0] + text[1])
            day = int(text[3] + text[4])
            year = int(text[6] + text[7] + text[8] + text[9])
            dayNumber = datetime.date(year, month, day).weekday()
            r['date'] = dayNumber
        return results

def find_sale_hours(barId):
    with engine.connect() as con:
        query = sql.text('SELECT hour FROM bills b where EXISTS(Select * From transactions t where t.barId = :barId && t.billId = b.billId);')
        rs = con.execute(query, barId=barId)
        results = [dict(row) for row in rs]
        for r in results:
            text = r['hour']
            hour = int(text[0] + text[1])
            hourNumber = hour - 15
            r['hour'] = hourNumber
        return results

def filter_beers(max_price):
    with engine.connect() as con:
        query = sql.text(
            "SELECT * FROM sells WHERE price < :max_price;"
        )

        rs = con.execute(query, max_price=max_price)
        results = [dict(row) for row in rs]
        for r in results:
            r['price'] = float(r['price'])
        return results


def get_bar_menu(barId):
    print(barId)
    with engine.connect() as con:
        query = sql.text(
            'SELECT a.barId, a.itemId, a.price, b.manufacturer, b.itemName, coalesce(c.like_count, 0) as likes \
                FROM sells as a \
                JOIN items AS b \
                ON a.itemId = b.itemId \
                LEFT OUTER JOIN (SELECT itemId, count(*) as like_count FROM likes GROUP BY itemid) as c \
                ON a.itemId = c.itemid \
                WHERE a.barId = :barId; \
            ')
        rs = con.execute(query, barId=barId)
        results = [dict(row) for row in rs]
        for i, _ in enumerate(results):
            if (results[i]['manufacturer'] == ""):
                results[i]['manufacturer'] = "N/A"
            results[i]['price'] = float(results[i]['price'])
        print("finished succesfully")
        return results


def get_bars_selling(beer):
    with engine.connect() as con:
        query = sql.text('SELECT a.barid, a.price, b.customers \
                FROM sells AS a \
                JOIN (SELECT barid, count(*) AS customers FROM frequents GROUP BY barid) as b \
                ON a.barid = b.barid \
                WHERE a.itemid = :beer \
                ORDER BY a.price; \
            ')
        rs = con.execute(query, beer=beer)
        results = [dict(row) for row in rs]
        for i, _ in enumerate(results):
            results[i]['price'] = float(results[i]['price'])
        return results


def get_bar_frequent_counts():
    with engine.connect() as con:
        query = sql.text('SELECT barid, count(*) as frequentCount \
                FROM frequents \
                GROUP BY barid; \
            ')
        rs = con.execute(query)
        results = [dict(row) for row in rs]
        return results


def get_bar_cities():
    with engine.connect() as con:
        rs = con.execute('SELECT DISTINCT city FROM bars;')
        return [row['city'] for row in rs]


def get_beers():
    print("Doing this....")
    """Gets a list of beer names from the beers table."""

    with engine.connect() as con:
        rs = con.execute('SELECT itemId, itemName, manufacturer FROM items;')
        return [dict(row) for row in rs]


def get_beer_manufacturers(itemId):
    print("Getting manufacturers")
    with engine.connect() as con:
        if itemId is None:
            rs = con.execute('SELECT DISTINCT manufacturer FROM items;')
            print("returning succesfully")
            return [row['manufacturer'] for row in rs]

        query = sql.text('SELECT manufacturer FROM items WHERE itemId = :itemId;')
        rs = con.execute(query, itemId=itemId)
        result = rs.first()
        if result is None:
            print("Returning none")
            return None
        print("Succesful")
        return result['manufacturer']


def get_drinkers():
    with engine.connect() as con:
        rs = con.execute('SELECT drinkerId, drinkerName, address, phone FROM drinkers;')
        return [dict(row) for row in rs]


def get_likes(drinker_name):
    """Gets a list of beers liked by the drinker provided."""

    with engine.connect() as con:
        query = sql.text('SELECT itemId FROM likes WHERE drinkerId = :name;')
        rs = con.execute(query, name=drinker_name)
        return [row['item'] for row in rs]


def get_drinker_info(drinkerId):
    with engine.connect() as con:
        query = sql.text('SELECT drinkerId, drinkerName, address, phone FROM drinkers WHERE drinkerId = :drinkerId;')
        rs = con.execute(query, drinkerId=drinkerId)
        result = rs.first()
        if result is None:
            return None
        return dict(result)

def get_trans_info(drinkerId):
    with engine.connect() as con:
        query=sql.text('select D.drinkerName, B.barName, I.itemName, T.price, B1.hour from DrinkingProject.transactions T, DrinkingProject.bars B, \
            DrinkingProject.items I, DrinkingProject.bills B1, DrinkingProject.drinkers D \
            where T.drinkerId=:drinkerId and T.barId=B.barId and T.itemId=I.itemId and T.billId=B1.billId  and D.drinkerId=T.drinkerId\
            order by hour;' 
            )
        rs=con.execute(query,drinkerId=drinkerId)
        if rs is None:
            print("returned none")
            return None
        return [dict(row) for row in rs]

def get_trans_count(drinkerId):
    with engine.connect() as con:
        query=sql.text('select itemId, count(itemId) as counts from DrinkingProject.transactions T where T.drinkerId=:drinkerId group by itemId')
        rs=con.execute(query,drinkerId=drinkerId)
        if rs is None:
            return None
        return [dict(row) for row in rs]

def get_item_pop(itemId):
    with engine.connect() as con:
        query=sql.text('select T.barid, count(T.barId) as sold from DrinkingProject.transactions T where T.itemId=:itemId group by T.barId order by sold desc limit 25')
        rs=con.execute(query,itemId=itemId)
        if rs is None: 
            return None
        return [dict(row) for row in rs]

def get_item_drinker_pop(itemId):
    with engine.connect() as con:
        query=sql.text('select T.drinkerId, T.itemId, count(T.itemid) as consumers from DrinkingProject.transactions T where T.itemid=:itemId group by drinkerid order by consumers desc limit 25')
        rs=con.execute(query,itemId=itemId)
        if rs is None:
            return None
        return [dict(row) for row in rs]

def get_item_time_dist(itemId):
    with engine.connect() as con:
        query=sql.text("select B.date from DrinkingProject.bills B, DrinkingProject.transactions T where T.billId=B.billId and T.itemId=:itemId")
        rs=con.execute(query,itemId=itemId)
        results = [dict(row) for row in rs]
        for r in results:
            text = r['date']
            month = int(text[0] + text[1])
            day = int(text[3] + text[4])
            year = int(text[6] + text[7] + text[8] + text[9])
            dayNumber = datetime.date(year, month, day).weekday()
            r['date'] = dayNumber
        return results


def get_item_dist(itemId):
    with engine.connect() as con:
        query=sql.text("select B.hour from DrinkingProject.bills B ,DrinkingProject.transactions T where T.billId=B.billId and T.itemId=:itemId")
        rs=con.execute(query,itemId=itemId)
        results = [dict(row) for row in rs]
        for r in results:
            text = r['hour']
            hour = int(text[0] + text[1])
            hourNumber = hour - 15
            r['hour'] = hourNumber
        return results

def drinker_spend_month(drinkerId):
    with engine.connect() as con:
        query=sql.text("select B.date, price from DrinkingProject.bills B, DrinkingProject.transactions T where  T.billId=B.billId and T.drinkerId=:drinkerId")
        rs=con.execute(query,drinkerId=drinkerId)
        results= [dict(row) for row in rs]
        for r in results:
            text=r['date']
            month=int(text[0]+text[1])
            r['date']=month
        return results

def drinker_spend_day(drinkerId):
    with engine.connect() as con: 
        query=sql.text("select B.date, price from DrinkingProject.bills B, DrinkingProject.transactions T where  T.billId=B.billId and T.drinkerId=:drinkerId")
        rs=con.execute(query,drinkerId=drinkerId)
        results=[dict(row)for row in rs]
        for r in results:
            text = r['date']
            month = int(text[0] + text[1])
            day = int(text[3] + text[4])
            year = int(text[6] + text[7] + text[8] + text[9])
            dayNumber = datetime.date(year, month, day).weekday()
            r['date'] = dayNumber
        return results

def drinker_spend_week(drinkerId):
    with engine.connect() as con:
        query=sql.text('select B.date, price from DrinkingProject.bills B, DrinkingProject.transactions T where  T.billId=B.billId and T.drinkerId=:drinkerId')
        rs=con.execute(query,drinkerId=drinkerId)
        results=[dict(row) for row in rs]
        for r in results:
            text = r['date']
            month = int(text[0] + text[1])
            day = int(text[3] + text[4])
            year = int(text[6] + text[7] + text[8] + text[9])
            week = datetime.date(year, month, day).strftime("%U")
            week = int(week)
            r['date'] = week
        return results