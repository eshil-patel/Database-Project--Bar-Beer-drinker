(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"],{

/***/ "./src/$$_lazy_route_resource lazy recursive":
/*!**********************************************************!*\
  !*** ./src/$$_lazy_route_resource lazy namespace object ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function webpackEmptyAsyncContext(req) {
	// Here Promise.resolve().then() is used instead of new Promise() to prevent
	// uncaught exception popping up in devtools
	return Promise.resolve().then(function() {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	});
}
webpackEmptyAsyncContext.keys = function() { return []; };
webpackEmptyAsyncContext.resolve = webpackEmptyAsyncContext;
module.exports = webpackEmptyAsyncContext;
webpackEmptyAsyncContext.id = "./src/$$_lazy_route_resource lazy recursive";

/***/ }),

/***/ "./src/app/app-routing.module.ts":
/*!***************************************!*\
  !*** ./src/app/app-routing.module.ts ***!
  \***************************************/
/*! exports provided: AppRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppRoutingModule", function() { return AppRoutingModule; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _welcome_welcome_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./welcome/welcome.component */ "./src/app/welcome/welcome.component.ts");
/* harmony import */ var _bar_details_bar_details_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./bar-details/bar-details.component */ "./src/app/bar-details/bar-details.component.ts");
/* harmony import */ var _beer_details_beer_details_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./beer-details/beer-details.component */ "./src/app/beer-details/beer-details.component.ts");
/* harmony import */ var _beers_beers_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./beers/beers.component */ "./src/app/beers/beers.component.ts");
/* harmony import */ var _insight_insight_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./insight/insight.component */ "./src/app/insight/insight.component.ts");
/* harmony import */ var _sqlqueryinterface_interface_details_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./sqlqueryinterface/interface-details.component */ "./src/app/sqlqueryinterface/interface-details.component.ts");
/* harmony import */ var _modifications_modifications_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./modifications/modifications.component */ "./src/app/modifications/modifications.component.ts");
/* harmony import */ var _drinker_drinker_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./drinker/drinker.component */ "./src/app/drinker/drinker.component.ts");
/* harmony import */ var _drinker_details_drinker_details_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./drinker-details/drinker-details.component */ "./src/app/drinker-details/drinker-details.component.ts");
/* harmony import */ var _items_items_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./items/items.component */ "./src/app/items/items.component.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};












var routes = [
    {
        path: '',
        pathMatch: 'full',
        redirectTo: 'bars'
    },
    {
        path: 'static',
        pathMatch: 'full',
        redirectTo: 'bars'
    },
    {
        path: 'bars',
        pathMatch: 'full',
        component: _welcome_welcome_component__WEBPACK_IMPORTED_MODULE_2__["WelcomeComponent"]
    },
    {
        path: 'bars/:bar',
        pathMatch: 'full',
        component: _bar_details_bar_details_component__WEBPACK_IMPORTED_MODULE_3__["BarDetailsComponent"]
    },
    {
        path: 'items-forsale',
        pathMatch: 'full',
        component: _beers_beers_component__WEBPACK_IMPORTED_MODULE_5__["BeersComponent"]
    },
    {
        path: 'beers/:beer',
        pathMatch: 'full',
        component: _beer_details_beer_details_component__WEBPACK_IMPORTED_MODULE_4__["BeerDetailsComponent"]
    },
    {
        path: 'insight',
        pathMatch: 'full',
        component: _insight_insight_component__WEBPACK_IMPORTED_MODULE_6__["InsightComponent"]
    },
    {
        path: 'sqlqueryinterface',
        pathMatch: 'full',
        component: _sqlqueryinterface_interface_details_component__WEBPACK_IMPORTED_MODULE_7__["InterfaceDetailsComponent"]
    },
    {
        path: 'modifications',
        pathMatch: 'full',
        component: _modifications_modifications_component__WEBPACK_IMPORTED_MODULE_8__["ModificationsComponent"]
    },
    {
        path: 'drinker',
        pathMatch: 'full',
        component: _drinker_drinker_component__WEBPACK_IMPORTED_MODULE_9__["DrinkerComponent"]
    },
    {
        path: 'drinker/:drinker',
        pathMatch: 'full',
        component: _drinker_details_drinker_details_component__WEBPACK_IMPORTED_MODULE_10__["DrinkerDetailsComponent"]
    },
    {
        path: 'items/:items',
        pathMatch: 'full',
        component: _items_items_component__WEBPACK_IMPORTED_MODULE_11__["ItemsComponent"]
    }
];
var AppRoutingModule = /** @class */ (function () {
    function AppRoutingModule() {
    }
    AppRoutingModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"])({
            imports: [_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"].forRoot(routes)],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"]]
        })
    ], AppRoutingModule);
    return AppRoutingModule;
}());



/***/ }),

/***/ "./src/app/app.component.css":
/*!***********************************!*\
  !*** ./src/app/app.component.css ***!
  \***********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2FwcC5jb21wb25lbnQuY3NzIn0= */"

/***/ }),

/***/ "./src/app/app.component.html":
/*!************************************!*\
  !*** ./src/app/app.component.html ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<nav class=\"navbar navbar-expand-lg navbar-light bg-light\">\n  <a class=\"navbar-brand\" href=\"#\">Bar Beer Drinker</a>\n  <button class=\"navbar-toggler\" type=\"button\" data-toggle=\"collapse\" data-target=\"#navbarNav\" aria-controls=\"navbarNav\"\n    aria-expanded=\"false\" aria-label=\"Toggle navigation\">\n    <span class=\"navbar-toggler-icon\"></span>\n  </button>\n  <div class=\"collapse navbar-collapse\" id=\"navbarNav\">\n    <ul class=\"navbar-nav\">\n      <li class=\"nav-item\" routerLinkActive=\"active\">\n        <a class=\"nav-link\" routerLink=\"/bars\">Home</a>\n      </li>\n      <li class=\"nav-item\" routerLinkActive=\"active\">\n        <a class=\"nav-link\" routerLink=\"/items-forsale\">Items</a>\n      </li>\n      <li class=\"nav-item\" routerLinkActive=\"active\">\n        <a class=\"nav-link\" routerLink=\"/drinker\">Drinker</a>\n      </li>\n      <li class=\"nav-item\" routerLinkActive=\"active\">\n        <a class=\"nav-link\" routerLink=\"/insight\">Frequents Chart</a>\n      </li>\n      <li class=\"nav-item\" routerLinkActive=\"active\">\n        <a class=\"nav-link\" routerLink=\"/sqlqueryinterface\">SQL Query Interface</a>\n      </li>\n      <li class=\"nav-item\" routerLinkActive=\"active\">\n        <a class=\"nav-link\" routerLink=\"/modifications\">Modifications</a>\n      </li>\n    </ul>\n  </div>\n</nav>\n\n<router-outlet></router-outlet>"

/***/ }),

/***/ "./src/app/app.component.ts":
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/*! exports provided: AppComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppComponent", function() { return AppComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};

var AppComponent = /** @class */ (function () {
    function AppComponent() {
        this.title = 'bar-beer-drinker-ui';
    }
    AppComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-root',
            template: __webpack_require__(/*! ./app.component.html */ "./src/app/app.component.html"),
            styles: [__webpack_require__(/*! ./app.component.css */ "./src/app/app.component.css")]
        })
    ], AppComponent);
    return AppComponent;
}());



/***/ }),

/***/ "./src/app/app.module.ts":
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/*! exports provided: AppModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppModule", function() { return AppModule; });
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/fesm5/platform-browser.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/platform-browser/animations */ "./node_modules/@angular/platform-browser/fesm5/animations.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var primeng_dropdown__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! primeng/dropdown */ "./node_modules/primeng/dropdown.js");
/* harmony import */ var primeng_dropdown__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(primeng_dropdown__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var primeng_table__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! primeng/table */ "./node_modules/primeng/table.js");
/* harmony import */ var primeng_table__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(primeng_table__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _app_routing_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./app-routing.module */ "./src/app/app-routing.module.ts");
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./app.component */ "./src/app/app.component.ts");
/* harmony import */ var _welcome_welcome_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./welcome/welcome.component */ "./src/app/welcome/welcome.component.ts");
/* harmony import */ var _bar_details_bar_details_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./bar-details/bar-details.component */ "./src/app/bar-details/bar-details.component.ts");
/* harmony import */ var _beer_details_beer_details_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./beer-details/beer-details.component */ "./src/app/beer-details/beer-details.component.ts");
/* harmony import */ var _beers_beers_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./beers/beers.component */ "./src/app/beers/beers.component.ts");
/* harmony import */ var _insight_insight_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./insight/insight.component */ "./src/app/insight/insight.component.ts");
/* harmony import */ var _sqlqueryinterface_interface_details_component__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./sqlqueryinterface/interface-details.component */ "./src/app/sqlqueryinterface/interface-details.component.ts");
/* harmony import */ var _modifications_modifications_component__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./modifications/modifications.component */ "./src/app/modifications/modifications.component.ts");
/* harmony import */ var _drinker_drinker_component__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./drinker/drinker.component */ "./src/app/drinker/drinker.component.ts");
/* harmony import */ var _drinker_details_drinker_details_component__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ./drinker-details/drinker-details.component */ "./src/app/drinker-details/drinker-details.component.ts");
/* harmony import */ var _items_items_component__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ./items/items.component */ "./src/app/items/items.component.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};



















var AppModule = /** @class */ (function () {
    function AppModule() {
    }
    AppModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            declarations: [
                _app_component__WEBPACK_IMPORTED_MODULE_8__["AppComponent"],
                _welcome_welcome_component__WEBPACK_IMPORTED_MODULE_9__["WelcomeComponent"],
                _bar_details_bar_details_component__WEBPACK_IMPORTED_MODULE_10__["BarDetailsComponent"],
                _beer_details_beer_details_component__WEBPACK_IMPORTED_MODULE_11__["BeerDetailsComponent"],
                _beers_beers_component__WEBPACK_IMPORTED_MODULE_12__["BeersComponent"],
                _insight_insight_component__WEBPACK_IMPORTED_MODULE_13__["InsightComponent"],
                _sqlqueryinterface_interface_details_component__WEBPACK_IMPORTED_MODULE_14__["InterfaceDetailsComponent"],
                _modifications_modifications_component__WEBPACK_IMPORTED_MODULE_15__["ModificationsComponent"],
                _drinker_drinker_component__WEBPACK_IMPORTED_MODULE_16__["DrinkerComponent"],
                _drinker_details_drinker_details_component__WEBPACK_IMPORTED_MODULE_17__["DrinkerDetailsComponent"],
                _items_items_component__WEBPACK_IMPORTED_MODULE_18__["ItemsComponent"]
            ],
            imports: [
                _angular_platform_browser__WEBPACK_IMPORTED_MODULE_0__["BrowserModule"],
                _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_3__["BrowserAnimationsModule"],
                _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClientModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormsModule"],
                primeng_dropdown__WEBPACK_IMPORTED_MODULE_5__["DropdownModule"],
                primeng_table__WEBPACK_IMPORTED_MODULE_6__["TableModule"],
                _app_routing_module__WEBPACK_IMPORTED_MODULE_7__["AppRoutingModule"]
            ],
            providers: [_angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"]],
            bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_8__["AppComponent"]]
        })
    ], AppModule);
    return AppModule;
}());



/***/ }),

/***/ "./src/app/bar-details/bar-details.component.css":
/*!*******************************************************!*\
  !*** ./src/app/bar-details/bar-details.component.css ***!
  \*******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".modification-info{\n    text-align: center\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvYmFyLWRldGFpbHMvYmFyLWRldGFpbHMuY29tcG9uZW50LmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtJQUNJLGtCQUFrQjtDQUNyQiIsImZpbGUiOiJzcmMvYXBwL2Jhci1kZXRhaWxzL2Jhci1kZXRhaWxzLmNvbXBvbmVudC5jc3MiLCJzb3VyY2VzQ29udGVudCI6WyIubW9kaWZpY2F0aW9uLWluZm97XG4gICAgdGV4dC1hbGlnbjogY2VudGVyXG59Il19 */"

/***/ }),

/***/ "./src/app/bar-details/bar-details.component.html":
/*!********************************************************!*\
  !*** ./src/app/bar-details/bar-details.component.html ***!
  \********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"jumbotron jumbotron-fluid\">\n    <div class=\"container\">\n        <h1 class=\"display-4\">{{ barDetails?.barName }}</h1>\n        <p class=\"bar-details\" *ngIf=\"barDetails\">\n            {{ barDetails?.address }} \n            <br>\n            {{ barDetails?.city }}, {{barDetails?.state }}\n            <br>\n            {{ barDetails?.phone }}\n        </p>\n        <br><br>\n        <p class=\"modification-info\"><b>You can add or modify transactions via the Modifications page.</b></p>\n    </div>\n</div>\n\n<!---<div class=\"container\">\n    <h2 class=\"text-center font-weight-light\">Top Drinkers</h2>\n    <br>\n    <p-table [value]=\"menu\">\n        <ng-template pTemplate=\"header\">\n            <tr>\n                <th>Items</th>\n                <th>Manufacturer</th>\n                <th>Price</th>\n                <th>Likes</th>\n            </tr>\n        </ng-template>\n        <ng-template pTemplate=\"body\" let-item>\n            <tr>\n                <td><a routerLink=\"/items/{{ item.itemName }}\">{{ item.itemName }}</a></td>\n                <td>{{ item.manufacturer }}</td>\n                <td>{{ item.price | currency }}</td>\n                <td>{{ item.likes }}</td>\n            </tr>\n        </ng-template>\n    </p-table>\n</div>--->\n\n<div class=\"container\">\n    <br>\n    <div id=\"topDrinkers\"></div>\n    <br>\n    <div id=\"topPurchases\"></div>\n    <br>\n    <div id=\"topManufacturers\"></div>\n    <br>\n    <div id=\"salesPerDay\"></div>\n    <br>\n    <div id=\"salesPerHour\"></div>\n    \n</div>\n\n<br><br>"

/***/ }),

/***/ "./src/app/bar-details/bar-details.component.ts":
/*!******************************************************!*\
  !*** ./src/app/bar-details/bar-details.component.ts ***!
  \******************************************************/
/*! exports provided: BarDetailsComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BarDetailsComponent", function() { return BarDetailsComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _bars_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../bars.service */ "./src/app/bars.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};



var BarDetailsComponent = /** @class */ (function () {
    function BarDetailsComponent(barService, route) {
        var _this = this;
        this.barService = barService;
        this.route = route;
        route.paramMap.subscribe(function (paramMap) {
            _this.barName = paramMap.get('bar');
            barService.getBar(_this.barName).subscribe(function (data) {
                _this.barDetails = data;
                console.log(_this.barDetails);
            }, function (error) {
                if (error.status === 404) {
                    alert('Bar not found');
                }
                else {
                    console.error(error.status + ' - ' + error.body);
                    alert('An error occurred on the server. Please check the browser console.');
                }
            });
            barService.getMenu(_this.barName).subscribe(function (data) {
                _this.menu = data;
            });
        });
        this.barService.getTopDrinkers(this.barName).subscribe(function (data) {
            console.log(data);
            var drinkerIds = [];
            var spent = [];
            data.forEach(function (drinkers) {
                drinkerIds.push(drinkers.drinkerId);
                spent.push(drinkers.spent);
            });
            _this.generateDrinkerChart(drinkerIds, spent);
        });
        this.barService.getTopPurchases(this.barName).subscribe(function (data) {
            console.log(data);
            var itemIds = [];
            var purchases = [];
            data.forEach(function (drinkers) {
                itemIds.push(drinkers.itemId);
                purchases.push(drinkers.purchases);
            });
            _this.generatePurchaseChart(itemIds, purchases);
        });
        this.barService.getTopManufacturers(this.barName).subscribe(function (data) {
            console.log(data);
            var manufacturers = [];
            var totalItemsSold = [];
            data.forEach(function (drinkers) {
                manufacturers.push(drinkers.manufacturer);
                totalItemsSold.push(drinkers.amtspent);
            });
            _this.generateManufacturerChart(manufacturers, totalItemsSold);
        });
        this.barService.getSaleDates(this.barName).subscribe(function (data) {
            var days = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"];
            var vals = [0, 0, 0, 0, 0, 0, 0];
            console.log(data);
            data.forEach(function (day) {
                vals[day.date] = vals[day.date] + 1;
            });
            _this.generateDayChart(days, vals);
        });
        this.barService.getSaleHours(this.barName).subscribe(function (data) {
            var times = ["3-4", "4-5", "5-6", "6-7", "7-8", "8-9", "9-10", "10-11", "11-11:59"];
            var values = [0, 0, 0, 0, 0, 0, 0, 0, 0];
            console.log(data);
            data.forEach(function (hour) {
                values[hour.hour] = values[hour.hour] + 1;
            });
            _this.generateHourChart(times, values);
        });
    }
    BarDetailsComponent.prototype.ngOnInit = function () {
    };
    BarDetailsComponent.prototype.generateDrinkerChart = function (drinkerIds, spent) {
        Highcharts.chart('topDrinkers', {
            chart: {
                type: 'column'
            },
            title: {
                text: 'Top Drinkers at this Bar'
            },
            xAxis: {
                categories: drinkerIds,
                title: {
                    text: 'Drinker Id'
                }
            },
            yAxis: {
                min: 0,
                title: {
                    text: 'Total Spent'
                },
                labels: {
                    format: '${value:,.0f}',
                    overflow: 'justify'
                }
            },
            plotOptions: {
                bar: {
                    dataLabels: {
                        enabled: true
                    }
                }
            },
            legend: {
                enabled: false
            },
            credits: {
                enabled: false
            },
            series: [{
                    data: spent, color: 'green'
                }]
        });
    };
    BarDetailsComponent.prototype.generatePurchaseChart = function (drinkerIds, spent) {
        Highcharts.chart('topPurchases', {
            chart: {
                type: 'column'
            },
            title: {
                text: 'Top Purchases at this Bar'
            },
            xAxis: {
                categories: drinkerIds,
                title: {
                    text: 'Item Id'
                }
            },
            yAxis: {
                min: 0,
                title: {
                    text: 'Total Purchases'
                },
                labels: {
                    overflow: 'justify'
                }
            },
            plotOptions: {
                bar: {
                    dataLabels: {
                        enabled: true
                    }
                }
            },
            legend: {
                enabled: false
            },
            credits: {
                enabled: false
            },
            series: [{
                    data: spent
                }]
        });
    };
    BarDetailsComponent.prototype.generateManufacturerChart = function (drinkerIds, spent) {
        Highcharts.chart('topManufacturers', {
            chart: {
                type: 'column'
            },
            title: {
                text: 'Top Manufacturers at this Bar'
            },
            xAxis: {
                categories: drinkerIds,
                title: {
                    text: 'Manufacturer'
                }
            },
            yAxis: {
                min: 0,
                title: {
                    text: 'Total Products Sold'
                },
                labels: {
                    overflow: 'justify'
                }
            },
            plotOptions: {
                bar: {
                    dataLabels: {
                        enabled: true
                    }
                }
            },
            legend: {
                enabled: false
            },
            credits: {
                enabled: false
            },
            series: [{
                    data: spent, color: 'orange'
                }]
        });
    };
    BarDetailsComponent.prototype.generateDayChart = function (drinkerIds, spent) {
        Highcharts.chart('salesPerDay', {
            chart: {
                type: 'column'
            },
            title: {
                text: 'Total Sales per Weekday'
            },
            xAxis: {
                categories: drinkerIds,
                title: {
                    text: 'Weekday'
                }
            },
            yAxis: {
                min: 0,
                title: {
                    text: 'Number of Sales'
                },
                labels: {
                    overflow: 'justify'
                }
            },
            plotOptions: {
                bar: {
                    dataLabels: {
                        enabled: true
                    }
                }
            },
            legend: {
                enabled: false
            },
            credits: {
                enabled: false
            },
            series: [{
                    data: spent, color: 'purple'
                }]
        });
    };
    BarDetailsComponent.prototype.generateHourChart = function (drinkerIds, spent) {
        Highcharts.chart('salesPerHour', {
            chart: {
                type: 'column'
            },
            title: {
                text: 'Total Sales per Hour'
            },
            xAxis: {
                categories: drinkerIds,
                title: {
                    text: 'Hour (PM)'
                }
            },
            yAxis: {
                min: 0,
                title: {
                    text: 'Number of Sales'
                },
                labels: {
                    overflow: 'justify'
                }
            },
            plotOptions: {
                bar: {
                    dataLabels: {
                        enabled: true
                    }
                }
            },
            legend: {
                enabled: false
            },
            credits: {
                enabled: false
            },
            series: [{
                    data: spent, color: 'grey'
                }]
        });
    };
    BarDetailsComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-bar-details',
            template: __webpack_require__(/*! ./bar-details.component.html */ "./src/app/bar-details/bar-details.component.html"),
            styles: [__webpack_require__(/*! ./bar-details.component.css */ "./src/app/bar-details/bar-details.component.css")]
        }),
        __metadata("design:paramtypes", [_bars_service__WEBPACK_IMPORTED_MODULE_2__["BarsService"],
            _angular_router__WEBPACK_IMPORTED_MODULE_1__["ActivatedRoute"]])
    ], BarDetailsComponent);
    return BarDetailsComponent;
}());



/***/ }),

/***/ "./src/app/bars.service.ts":
/*!*********************************!*\
  !*** ./src/app/bars.service.ts ***!
  \*********************************/
/*! exports provided: BarsService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BarsService", function() { return BarsService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};


var BarsService = /** @class */ (function () {
    function BarsService(http) {
        this.http = http;
    }
    BarsService.prototype.getBars = function () {
        return this.http.get('/api/bar');
    };
    BarsService.prototype.getBar = function (bar) {
        return this.http.get('/api/bar/' + bar);
    };
    BarsService.prototype.getMenu = function (bar) {
        return this.http.get('/api/menu/' + bar);
    };
    BarsService.prototype.getFrequentCounts = function () {
        return this.http.get('/api/frequents-data');
    };
    BarsService.prototype.getTopDrinkers = function (barId) {
        return this.http.get('/api/top-drinkers/' + barId);
    };
    BarsService.prototype.getTopPurchases = function (barId) {
        return this.http.get('/api/top-purchases/' + barId);
    };
    BarsService.prototype.getTopManufacturers = function (barId) {
        return this.http.get('/api/top-manufacturers/' + barId);
    };
    BarsService.prototype.getSaleDates = function (barId) {
        return this.http.get('/api/sale-dates/' + barId);
    };
    BarsService.prototype.getSaleHours = function (barId) {
        return this.http.get('/api/sale-hours/' + barId);
    };
    BarsService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"]])
    ], BarsService);
    return BarsService;
}());



/***/ }),

/***/ "./src/app/beer-details/beer-details.component.css":
/*!*********************************************************!*\
  !*** ./src/app/beer-details/beer-details.component.css ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".result-count {\r\n    font-size: 1.25rem;\r\n}\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvYmVlci1kZXRhaWxzL2JlZXItZGV0YWlscy5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0lBQ0ksbUJBQW1CO0NBQ3RCIiwiZmlsZSI6InNyYy9hcHAvYmVlci1kZXRhaWxzL2JlZXItZGV0YWlscy5jb21wb25lbnQuY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLnJlc3VsdC1jb3VudCB7XHJcbiAgICBmb250LXNpemU6IDEuMjVyZW07XHJcbn0iXX0= */"

/***/ }),

/***/ "./src/app/beer-details/beer-details.component.html":
/*!**********************************************************!*\
  !*** ./src/app/beer-details/beer-details.component.html ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"jumbotron jumbotron-fluid\">\r\n  <div class=\"container\">\r\n    <h1 class=\"display-4\">{{ beerName }}</h1>\r\n    <p class=\"beer-details\" *ngIf=\"manufacturer\">\r\n      Made by <i>{{ manufacturer }}</i>\r\n    </p>\r\n  </div>\r\n</div>\r\n\r\n<div class=\"container\">\r\n  <br>\r\n  <div>\r\n    <span class=\"font-weight-light result-count\">Sold at {{ beerLocations?.length }}</span>\r\n    <p-dropdown class=\"float-right text-left\" *ngIf=\"filterOptions\" [options]=\"filterOptions\" (onChange)=\"sortBy($event.value)\"></p-dropdown>\r\n  </div>\r\n  <br>\r\n  <p-table [value]=\"beerLocations\" sortMode=\"multiple\" sortField=\"price\">\r\n    <ng-template pTemplate=\"header\">\r\n      <tr>\r\n        <th>Bar</th>\r\n        <th>\r\n          Price\r\n        </th>\r\n        <th>Customers</th>\r\n      </tr>\r\n    </ng-template>\r\n    <ng-template pTemplate=\"body\" let-bar>\r\n      <tr>\r\n        <td><a routerLink=\"/bars/{{ bar.bar }}\">{{ bar.bar }}</a></td>\r\n        <td>{{ bar.price | currency }}</td>\r\n        <td>{{ bar.customers }}</td>\r\n      </tr>\r\n    </ng-template>\r\n  </p-table>\r\n</div>"

/***/ }),

/***/ "./src/app/beer-details/beer-details.component.ts":
/*!********************************************************!*\
  !*** ./src/app/beer-details/beer-details.component.ts ***!
  \********************************************************/
/*! exports provided: BeerDetailsComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BeerDetailsComponent", function() { return BeerDetailsComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _beers_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../beers.service */ "./src/app/beers.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};



var BeerDetailsComponent = /** @class */ (function () {
    function BeerDetailsComponent(beerService, route) {
        var _this = this;
        this.beerService = beerService;
        this.route = route;
        this.route.paramMap.subscribe(function (paramMap) {
            _this.beerName = paramMap.get('beer');
            _this.beerService.getBarsSelling(_this.beerName).subscribe(function (data) {
                _this.beerLocations = data;
            });
            _this.beerService.getBeerManufacturers(_this.beerName)
                .subscribe(function (data) {
                _this.manufacturer = data;
            });
            _this.filterOptions = [
                {
                    'label': 'Low price first',
                    'value': 'low price'
                },
                {
                    'label': 'High price first',
                    'value': 'high price'
                },
                {
                    'label': 'Most frequented first',
                    'value': 'high customer'
                },
                {
                    'label': 'Least frequented first',
                    'value': 'low customer'
                }
            ];
        });
    }
    BeerDetailsComponent.prototype.ngOnInit = function () {
    };
    BeerDetailsComponent.prototype.sortBy = function (selectedOption) {
        if (selectedOption === 'low price') {
            this.beerLocations.sort(function (a, b) {
                return a.price - b.price;
            });
        }
        else if (selectedOption === 'high price') {
            this.beerLocations.sort(function (a, b) {
                return b.price - a.price;
            });
        }
        else if (selectedOption === 'low customer') {
            this.beerLocations.sort(function (a, b) {
                return a.customers - b.customers;
            });
        }
        else if (selectedOption === 'high customer') {
            this.beerLocations.sort(function (a, b) {
                return b.customers - a.customers;
            });
        }
    };
    BeerDetailsComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-beer-details',
            template: __webpack_require__(/*! ./beer-details.component.html */ "./src/app/beer-details/beer-details.component.html"),
            styles: [__webpack_require__(/*! ./beer-details.component.css */ "./src/app/beer-details/beer-details.component.css")]
        }),
        __metadata("design:paramtypes", [_beers_service__WEBPACK_IMPORTED_MODULE_1__["BeersService"],
            _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"]])
    ], BeerDetailsComponent);
    return BeerDetailsComponent;
}());



/***/ }),

/***/ "./src/app/beers.service.ts":
/*!**********************************!*\
  !*** ./src/app/beers.service.ts ***!
  \**********************************/
/*! exports provided: BeersService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BeersService", function() { return BeersService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};


var BeersService = /** @class */ (function () {
    function BeersService(http) {
        this.http = http;
    }
    BeersService.prototype.getItems = function () {
        return this.http.get('/api/items');
    };
    BeersService.prototype.getBarsSelling = function (item) {
        return this.http.get("/api/bars-selling/" + item);
    };
    BeersService.prototype.getBeerManufacturers = function (item) {
        if (item) {
            return this.http.get("/api/beer-manufacturer/" + item);
        }
        return this.http.get('/api/beer-manufacturer');
    };
    BeersService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"]])
    ], BeersService);
    return BeersService;
}());



/***/ }),

/***/ "./src/app/beers/beers.component.css":
/*!*******************************************!*\
  !*** ./src/app/beers/beers.component.css ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2JlZXJzL2JlZXJzLmNvbXBvbmVudC5jc3MifQ== */"

/***/ }),

/***/ "./src/app/beers/beers.component.html":
/*!********************************************!*\
  !*** ./src/app/beers/beers.component.html ***!
  \********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"jumbotron jumbotron-fluid\">\r\n  <div class=\"container\">\r\n    <h1 class=\"display-4\">Find your favorite items!</h1>\r\n  </div>\r\n</div>\r\n<br>\r\n\r\n<div class=\"container\">\r\n  <h2 class=\"text-center font-weight-light\">Items</h2>\r\n  <p-table [value]=\"items\" [paginator]=\"true\" [rows]=\"10\">\r\n    <ng-template pTemplate=\"header\">\r\n      <tr>\r\n        <th>ItemId</th>\r\n        <th>Name</th> \r\n        <th>Manufacturer</th>\r\n      </tr>\r\n    </ng-template>\r\n    <ng-template pTemplate=\"body\" let-item>\r\n      <tr>\r\n        <td><a routerLink=\"/items/{{ item.itemId }}\">{{ item.itemId }}</a></td>\r\n        <td>{{ item.itemName }}</td>\r\n        <td>{{ item.manufacturer }}</td>\r\n      </tr>\r\n    </ng-template>\r\n  </p-table>\r\n  <br><br>\r\n</div>"

/***/ }),

/***/ "./src/app/beers/beers.component.ts":
/*!******************************************!*\
  !*** ./src/app/beers/beers.component.ts ***!
  \******************************************/
/*! exports provided: BeersComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BeersComponent", function() { return BeersComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _beers_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../beers.service */ "./src/app/beers.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};


var BeersComponent = /** @class */ (function () {
    function BeersComponent(beerService) {
        var _this = this;
        this.beerService = beerService;
        this.beerService.getItems().subscribe(function (data) {
            _this.items = data;
            _this.originalItemsList = data;
        });
        this.beerService.getBeerManufacturers().subscribe(function (data) {
            _this.manufacturerOptions = data.map(function (manf) {
                return {
                    label: manf,
                    value: manf,
                };
            });
        });
    }
    BeersComponent.prototype.ngOnInit = function () {
    };
    BeersComponent.prototype.filterBeers = function (manufacturer) {
        this.items = this.originalItemsList;
        if (manufacturer) {
            this.items = this.originalItemsList.filter(function (item) { return item.manufacturer === manufacturer; });
        }
    };
    BeersComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-beers',
            template: __webpack_require__(/*! ./beers.component.html */ "./src/app/beers/beers.component.html"),
            styles: [__webpack_require__(/*! ./beers.component.css */ "./src/app/beers/beers.component.css")]
        }),
        __metadata("design:paramtypes", [_beers_service__WEBPACK_IMPORTED_MODULE_1__["BeersService"]])
    ], BeersComponent);
    return BeersComponent;
}());



/***/ }),

/***/ "./src/app/drinker-details/drinker-details.component.css":
/*!***************************************************************!*\
  !*** ./src/app/drinker-details/drinker-details.component.css ***!
  \***************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2RyaW5rZXItZGV0YWlscy9kcmlua2VyLWRldGFpbHMuY29tcG9uZW50LmNzcyJ9 */"

/***/ }),

/***/ "./src/app/drinker-details/drinker-details.component.html":
/*!****************************************************************!*\
  !*** ./src/app/drinker-details/drinker-details.component.html ***!
  \****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"jumbotron jumbotron-fluid\">\n  <div class=\"container\">\n      <h1 class=\"display-4\">{{drinkerinfo?.drinkerName }}</h1>\n  </div>\n</div>\n\n<div class=\"container\">\n  <h2 class=\"text-center font-weight-light\">Transaction Information</h2>\n  <br>\n  <p-table [value]=\"transInfo\">\n      <ng-template pTemplate=\"header\">\n          <tr>\n              <th>Bar</th>\n              <th>Item</th>\n              <th>Price</th>\n              <th>Time</th>\n          </tr>\n      </ng-template>\n      <ng-template pTemplate=\"body\" let-trans>\n          <tr>\n              <td>{{ trans.barName }}</td>\n              <td>{{ trans.itemName }}</td>\n              <td>{{ trans.price | currency }}</td>\n              <td>{{ trans.hour }}</td>\n          </tr>\n      </ng-template>\n  </p-table>\n</div>\n<br><br>\n\n<div class=\"container\">\n        <br>\n        <div id=\"bargraph\"></div>\n      </div>\n<br>\n<br>\n<br>\n\n\n<div class=\"container\">\n    <br>\n    <div id='daygraph'></div>\n  </div>\n<br>\n<br>\n<br>\n\n<div class=\"container\">\n    <br>\n    <div id='DayWeekgraph'></div>\n  </div>\n<br>\n<br>\n<br>\n\n<div class=\"container\">\n    <br>\n    <div id='Weekgraph'></div>\n  </div>\n<br>\n<br>\n<br>\n\n"

/***/ }),

/***/ "./src/app/drinker-details/drinker-details.component.ts":
/*!**************************************************************!*\
  !*** ./src/app/drinker-details/drinker-details.component.ts ***!
  \**************************************************************/
/*! exports provided: DrinkerDetailsComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DrinkerDetailsComponent", function() { return DrinkerDetailsComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _drinker_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../drinker.service */ "./src/app/drinker.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};



var DrinkerDetailsComponent = /** @class */ (function () {
    function DrinkerDetailsComponent(drinkerService, route) {
        var _this = this;
        this.drinkerService = drinkerService;
        this.route = route;
        route.paramMap.subscribe(function (paramMap) {
            _this.drinkerId = paramMap.get('drinker');
            drinkerService.getdrinkerinfo(_this.drinkerId).subscribe(function (data) {
                _this.drinkerinfo = data;
            }, function (error) {
                if (error.status === 404) {
                    alert('Drinker not found');
                }
                else {
                    console.error(error.status + ' - ' + error.body);
                    alert('An error occurred on the server. Please check the browser console.');
                }
            });
            drinkerService.gettransinfo(_this.drinkerId).subscribe(function (data) { _this.transInfo = data; });
            drinkerService.gettranscounts(_this.drinkerId).subscribe(function (data) {
                console.log(data);
                var items = [];
                var count = [];
                data.forEach(function (item) {
                    items.push(item.itemId);
                    count.push(item.counts);
                });
                if (items.length > 0 && count.length > 0) {
                    _this.renderChart(items, count);
                }
                else {
                    alert('No transaction data for this drinker, try another drinker');
                    return;
                }
            });
            drinkerService.getdrinkermonth(_this.drinkerId).subscribe(function (data) {
                console.log(data);
                var months = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12];
                var count = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
                data.forEach(function (item) {
                    count[item.date] = count[item.date] + item.price;
                });
                _this.dayChart(months, count);
            });
            drinkerService.getdrinkerday(_this.drinkerId).subscribe(function (data) {
                console.log(data);
                var days = [0, 1, 2, 3, 4, 5, 6];
                var count = [0, 0, 0, 0, 0, 0, 0];
                data.forEach(function (item) {
                    count[item.date] = count[item.date] + item.price;
                });
                _this.DayofWeekChart(days, count);
            });
            _this.drinkerService.getdrinkerweek(_this.drinkerId).subscribe(function (data) {
                console.log(data);
                var week = [];
                var value = [];
                var i;
                var j;
                for (i = 0; i < 52; i++) {
                    week.push(i);
                }
                for (j = 0; j < 52; j++) {
                    value.push(0);
                }
                data.forEach(function (item) {
                    value[item.date] = value[item.date] + item.price;
                });
                _this.WeekChart(week, value);
            });
        });
    }
    DrinkerDetailsComponent.prototype.ngOnInit = function () {
    };
    DrinkerDetailsComponent.prototype.renderChart = function (item, counts) {
        Highcharts.chart('bargraph', {
            chart: {
                type: 'column'
            },
            title: {
                text: 'Items and Amount Drinker Ordered'
            },
            xAxis: {
                categories: item,
                title: {
                    text: 'ItemId'
                }
            },
            yAxis: {
                min: 0,
                title: {
                    text: 'Quantity ordered'
                },
                labels: {
                    overflow: 'justify'
                }
            },
            plotOptions: {
                bar: {
                    dataLabels: {
                        enabled: true
                    }
                }
            },
            legend: {
                enabled: false
            },
            credits: {
                enabled: false
            },
            series: [{
                    data: counts
                }]
        });
    };
    DrinkerDetailsComponent.prototype.WeekChart = function (week, counts) {
        Highcharts.chart('Weekgraph', {
            chart: {
                type: 'column'
            },
            title: {
                text: 'Spending Habits Per Week '
            },
            xAxis: {
                categories: week,
                title: {
                    text: 'Week Number'
                }
            },
            yAxis: {
                min: 0,
                title: {
                    text: 'Amount Spent During the Week'
                },
                labels: {
                    overflow: 'justify'
                }
            },
            plotOptions: {
                bar: {
                    dataLabels: {
                        enabled: true
                    }
                }
            },
            legend: {
                enabled: false
            },
            credits: {
                enabled: false
            },
            series: [{
                    data: counts, color: 'orange'
                }]
        });
    };
    DrinkerDetailsComponent.prototype.DayofWeekChart = function (days, value) {
        Highcharts.chart('DayWeekgraph', {
            chart: {
                type: 'column'
            },
            title: {
                text: 'Spending Habits Based on Day'
            },
            xAxis: {
                categories: days,
                title: {
                    text: 'Days of Week'
                }
            },
            yAxis: {
                min: 0,
                title: {
                    text: 'Amount spent Per Day'
                },
                labels: {
                    overflow: 'justify'
                }
            },
            plotOptions: {
                bar: {
                    dataLabels: {
                        enabled: true
                    }
                }
            },
            legend: {
                enabled: false
            },
            credits: {
                enabled: false
            },
            series: [{
                    data: value, color: 'red'
                }]
        });
    };
    DrinkerDetailsComponent.prototype.dayChart = function (months, counts) {
        Highcharts.chart('daygraph', {
            chart: {
                type: 'column'
            },
            title: {
                text: 'Spending Habits by Month'
            },
            xAxis: {
                categories: months,
                title: {
                    text: 'Months'
                }
            },
            yAxis: {
                min: 0,
                title: {
                    text: 'Amount Spent per Week'
                },
                labels: {
                    overflow: 'justify'
                }
            },
            plotOptions: {
                bar: {
                    dataLabels: {
                        enabled: true
                    }
                }
            },
            legend: {
                enabled: false
            },
            credits: {
                enabled: false
            },
            series: [{
                    data: counts, color: 'green'
                }]
        });
    };
    DrinkerDetailsComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-drinker-details',
            template: __webpack_require__(/*! ./drinker-details.component.html */ "./src/app/drinker-details/drinker-details.component.html"),
            styles: [__webpack_require__(/*! ./drinker-details.component.css */ "./src/app/drinker-details/drinker-details.component.css")]
        }),
        __metadata("design:paramtypes", [_drinker_service__WEBPACK_IMPORTED_MODULE_2__["DrinkerService"],
            _angular_router__WEBPACK_IMPORTED_MODULE_1__["ActivatedRoute"]])
    ], DrinkerDetailsComponent);
    return DrinkerDetailsComponent;
}());



/***/ }),

/***/ "./src/app/drinker.service.ts":
/*!************************************!*\
  !*** ./src/app/drinker.service.ts ***!
  \************************************/
/*! exports provided: DrinkerService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DrinkerService", function() { return DrinkerService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};


var DrinkerService = /** @class */ (function () {
    function DrinkerService(http) {
        this.http = http;
    }
    DrinkerService.prototype.getDrinkers = function () {
        return this.http.get('/api/drinker');
    };
    DrinkerService.prototype.getdrinkerinfo = function (drinkerId) {
        return this.http.get('/api/drinker/' + drinkerId);
    };
    DrinkerService.prototype.gettransinfo = function (drinkerId) {
        return this.http.get('/api/trans/' + drinkerId);
    };
    DrinkerService.prototype.gettranscounts = function (drinkerId) {
        return this.http.get('/api/transcount/' + drinkerId);
    };
    DrinkerService.prototype.getdrinkermonth = function (drinkerId) {
        return this.http.get('/api/drinkermonth/' + drinkerId);
    };
    DrinkerService.prototype.getdrinkerday = function (drinkerId) {
        return this.http.get('/api/drinkerday/' + drinkerId);
    };
    DrinkerService.prototype.getdrinkerweek = function (drinkerId) {
        return this.http.get('/api/drinkerweek/' + drinkerId);
    };
    DrinkerService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"]])
    ], DrinkerService);
    return DrinkerService;
}());



/***/ }),

/***/ "./src/app/drinker/drinker.component.css":
/*!***********************************************!*\
  !*** ./src/app/drinker/drinker.component.css ***!
  \***********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2RyaW5rZXIvZHJpbmtlci5jb21wb25lbnQuY3NzIn0= */"

/***/ }),

/***/ "./src/app/drinker/drinker.component.html":
/*!************************************************!*\
  !*** ./src/app/drinker/drinker.component.html ***!
  \************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"jumbotron jumbotron-fluid\">\n  <div class=\"container\">\n    <h1 class=\"display-4\">Drinkers Page</h1>\n    <p class=\"lead\">A list of drinkers who frequent various bars and like various things</p>\n  </div>\n</div><div class=\"container\">\n  <h2 class=\"text-center font-weight-light\">Drinkers</h2>\n  <p-table [value]=\"drinker\" [paginator]=\"true\" [rows]=\"50\">\n    <ng-template pTemplate=\"header\">\n        <tr>\n          <th>DrinkerId</th>\n          <th>Name</th>\n          <th>Address</th>\n          <th>Phone</th>\n        </tr>\n    </ng-template>\n    <ng-template pTemplate=\"body\" let-drinker>\n        <tr>\n          <td>\n            <a routerLink=\"/drinker/{{ drinker.drinkerId }}\">\n              {{ drinker.drinkerId }}\n            </a>\n          </td>\n          <td>{{ drinker.drinkerName }}</td>\n          <td>{{ drinker.address }}</td>\n          <td>{{ drinker.phone }}</td>\n        </tr>\n    </ng-template>\n  </p-table>\n</div>\n\n<br><br>\n\n"

/***/ }),

/***/ "./src/app/drinker/drinker.component.ts":
/*!**********************************************!*\
  !*** ./src/app/drinker/drinker.component.ts ***!
  \**********************************************/
/*! exports provided: DrinkerComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DrinkerComponent", function() { return DrinkerComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _drinker_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../drinker.service */ "./src/app/drinker.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};


var DrinkerComponent = /** @class */ (function () {
    function DrinkerComponent(drinkerService) {
        this.drinkerService = drinkerService;
    }
    DrinkerComponent.prototype.ngOnInit = function () {
        this.getDrinkers();
    };
    DrinkerComponent.prototype.getDrinkers = function () {
        var _this = this;
        this.drinkerService.getDrinkers().subscribe(function (data) {
            _this.drinker = data;
        }, function (error) {
            alert('Could not retrieve a list of drinkers');
        });
    };
    DrinkerComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-drinker',
            template: __webpack_require__(/*! ./drinker.component.html */ "./src/app/drinker/drinker.component.html"),
            styles: [__webpack_require__(/*! ./drinker.component.css */ "./src/app/drinker/drinker.component.css")]
        }),
        __metadata("design:paramtypes", [_drinker_service__WEBPACK_IMPORTED_MODULE_1__["DrinkerService"]])
    ], DrinkerComponent);
    return DrinkerComponent;
}());



/***/ }),

/***/ "./src/app/form-service.service.ts":
/*!*****************************************!*\
  !*** ./src/app/form-service.service.ts ***!
  \*****************************************/
/*! exports provided: FormServiceService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FormServiceService", function() { return FormServiceService; });
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};


var FormServiceService = /** @class */ (function () {
    function FormServiceService(http) {
        this.http = http;
    }
    FormServiceService.prototype.sendQueries = function (query) {
        return this.http.post('/api/form-example', query, { responseType: 'text' });
    };
    FormServiceService.prototype.getResults = function () {
        return this.http.get('/api/form-example');
    };
    FormServiceService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_0__["HttpClient"]])
    ], FormServiceService);
    return FormServiceService;
}());



/***/ }),

/***/ "./src/app/insight/insight.component.css":
/*!***********************************************!*\
  !*** ./src/app/insight/insight.component.css ***!
  \***********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2luc2lnaHQvaW5zaWdodC5jb21wb25lbnQuY3NzIn0= */"

/***/ }),

/***/ "./src/app/insight/insight.component.html":
/*!************************************************!*\
  !*** ./src/app/insight/insight.component.html ***!
  \************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"container\">\n    <br>\n    <div id=\"bargraph\"></div>\n  </div>"

/***/ }),

/***/ "./src/app/insight/insight.component.ts":
/*!**********************************************!*\
  !*** ./src/app/insight/insight.component.ts ***!
  \**********************************************/
/*! exports provided: InsightComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "InsightComponent", function() { return InsightComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _bars_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../bars.service */ "./src/app/bars.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};


var InsightComponent = /** @class */ (function () {
    function InsightComponent(barService) {
        var _this = this;
        this.barService = barService;
        this.barService.getFrequentCounts().subscribe(function (data) {
            console.log(data);
            var bars = [];
            var counts = [];
            data.forEach(function (bar) {
                bars.push(bar.bar);
                counts.push(bar.frequentCount);
            });
            _this.renderChart(bars, counts);
        });
    }
    InsightComponent.prototype.ngOnInit = function () {
    };
    InsightComponent.prototype.renderChart = function (bars, counts) {
        Highcharts.chart('bargraph', {
            chart: {
                type: 'column'
            },
            title: {
                text: 'Frequenting count at bars'
            },
            xAxis: {
                categories: bars,
                title: {
                    text: 'Bar Id'
                }
            },
            yAxis: {
                min: 0,
                title: {
                    text: 'Number of customers'
                },
                labels: {
                    overflow: 'justify'
                }
            },
            plotOptions: {
                bar: {
                    dataLabels: {
                        enabled: true
                    }
                }
            },
            legend: {
                enabled: false
            },
            credits: {
                enabled: false
            },
            series: [{
                    data: counts
                }]
        });
    };
    InsightComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-insight',
            template: __webpack_require__(/*! ./insight.component.html */ "./src/app/insight/insight.component.html"),
            styles: [__webpack_require__(/*! ./insight.component.css */ "./src/app/insight/insight.component.css")]
        }),
        __metadata("design:paramtypes", [_bars_service__WEBPACK_IMPORTED_MODULE_1__["BarsService"]])
    ], InsightComponent);
    return InsightComponent;
}());



/***/ }),

/***/ "./src/app/items.service.ts":
/*!**********************************!*\
  !*** ./src/app/items.service.ts ***!
  \**********************************/
/*! exports provided: ItemsService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ItemsService", function() { return ItemsService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};


var ItemsService = /** @class */ (function () {
    function ItemsService(http) {
        this.http = http;
    }
    ItemsService.prototype.getitem = function (itemId) {
        return this.http.get('/api/getiteminfo/' + itemId);
    };
    ItemsService.prototype.getpop = function (itemId) {
        return this.http.get('api/items/' + itemId);
    };
    ItemsService.prototype.getitemdrinkerpop = function (itemId) {
        return this.http.get('/api/itemdrinker/' + itemId);
    };
    ItemsService.prototype.getitemdaydist = function (itemId) {
        return this.http.get('/api/itemdays/' + itemId);
    };
    ItemsService.prototype.getitemtimedist = function (itemId) {
        return this.http.get('/api/itemtime/' + itemId);
    };
    ItemsService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"]])
    ], ItemsService);
    return ItemsService;
}());



/***/ }),

/***/ "./src/app/items/items.component.css":
/*!*******************************************!*\
  !*** ./src/app/items/items.component.css ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2l0ZW1zL2l0ZW1zLmNvbXBvbmVudC5jc3MifQ== */"

/***/ }),

/***/ "./src/app/items/items.component.html":
/*!********************************************!*\
  !*** ./src/app/items/items.component.html ***!
  \********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"jumbotron jumbotron-fluid\">\n  <div class=\"container\">\n    <h1 class=\"display-4\">{{item.itemName}}</h1>\n    <p class=\"lead\">Stats about this item</p>\n  </div>\n</div>\n\n<div class=\"container\">\n  <br>\n  <div id=\"thisgraph\"></div>\n</div>\n<br>\n<br>\n<br>\n\n<div class=\"container\">\n  <br>\n  <div id=\"drinkergraph\"></div>\n</div>\n<br>\n<br>\n<br>\n\n<div class=\"container\">\n  <br>\n  <div id='daygraph'></div>\n</div>\n<br>\n<br>\n<br>\n\n<div class=\"container\">\n  <br>\n  <div id='timegraph'></div>\n</div>\n<br>\n<br>\n<br>"

/***/ }),

/***/ "./src/app/items/items.component.ts":
/*!******************************************!*\
  !*** ./src/app/items/items.component.ts ***!
  \******************************************/
/*! exports provided: ItemsComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ItemsComponent", function() { return ItemsComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _items_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../items.service */ "./src/app/items.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};



var ItemsComponent = /** @class */ (function () {
    function ItemsComponent(itemService, route) {
        var _this = this;
        this.itemService = itemService;
        this.route = route;
        this.route.paramMap.subscribe(function (paramMap) {
            _this.itemName = paramMap.get('items');
            _this.itemService.getitem(_this.itemName).subscribe(function (data) { _this.item = data; });
            _this.itemService.getpop(_this.itemName).subscribe(function (data) {
                console.log(data);
                var bar = [];
                var counter = [];
                data.forEach(function (pop) {
                    bar.push(pop.barid);
                    console.log(pop.barid);
                    counter.push(pop.sold);
                });
                _this.renderChart(bar, counter);
            });
            _this.itemService.getitemdrinkerpop(_this.itemName).subscribe(function (data) {
                console.log(data);
                var drinker = [];
                var counter = [];
                data.forEach(function (pop) {
                    drinker.push(pop.drinkerId);
                    counter.push(pop.consumers);
                });
                _this.drinkerChart(drinker, counter);
            });
            _this.itemService.getitemdaydist(_this.itemName).subscribe(function (data) {
                console.log(data);
                var day = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
                var counter = [0, 0, 0, 0, 0, 0, 0];
                data.forEach(function (pop) {
                    counter[pop.date] = counter[pop.date] + 1;
                });
                _this.dayChart(day, counter);
            });
            _this.itemService.getitemtimedist(_this.itemName).subscribe(function (data) {
                console.log(data);
                var times = ["3-4", "4-5", "5-6", "6-7", "7-8", "8-9", "9-10", "10-11", "11-11:59"];
                var values = [0, 0, 0, 0, 0, 0, 0, 0, 0];
                data.forEach(function (pop) {
                    values[pop.hour] = values[pop.hour] + 1;
                });
                _this.timeChart(times, values);
            });
        });
    }
    ItemsComponent.prototype.ngOnInit = function () {
    };
    ItemsComponent.prototype.renderChart = function (bar, counter) {
        Highcharts.chart('thisgraph', {
            chart: {
                type: 'column'
            },
            title: {
                text: 'Bars who sold this item'
            },
            xAxis: {
                categories: bar,
                title: {
                    text: 'BarID'
                }
            },
            yAxis: {
                min: 0,
                title: {
                    text: 'Number sold of this item'
                },
                labels: {
                    overflow: 'justify'
                }
            },
            plotOptions: {
                bar: {
                    dataLabels: {
                        enabled: true
                    }
                }
            },
            legend: {
                enabled: false
            },
            credits: {
                enabled: false
            },
            series: [{
                    data: counter
                }]
        });
    };
    ItemsComponent.prototype.timeChart = function (time, counter) {
        Highcharts.chart('timegraph', {
            chart: {
                type: 'column'
            },
            title: {
                text: 'Time when this item is sold '
            },
            xAxis: {
                categories: time,
                title: {
                    text: 'Time (PM)'
                }
            },
            yAxis: {
                min: 0,
                title: {
                    text: 'Number sold of this item'
                },
                labels: {
                    overflow: 'justify'
                }
            },
            plotOptions: {
                bar: {
                    dataLabels: {
                        enabled: true
                    }
                }
            },
            legend: {
                enabled: false
            },
            credits: {
                enabled: false
            },
            series: [{
                    data: counter, color: 'green'
                }]
        });
    };
    ItemsComponent.prototype.drinkerChart = function (drinker, counter) {
        Highcharts.chart('drinkergraph', {
            chart: {
                type: 'column'
            },
            title: {
                text: 'People who bought this item '
            },
            xAxis: {
                categories: drinker,
                title: {
                    text: 'DrinkerID'
                }
            },
            yAxis: {
                min: 0,
                title: {
                    text: 'Number of items bought'
                },
                labels: {
                    overflow: 'justify'
                }
            },
            plotOptions: {
                bar: {
                    dataLabels: {
                        enabled: true
                    }
                }
            },
            legend: {
                enabled: false
            },
            credits: {
                enabled: false
            },
            series: [{
                    data: counter, color: 'red'
                }]
        });
    };
    ItemsComponent.prototype.dayChart = function (day, counter) {
        Highcharts.chart('daygraph', {
            chart: {
                type: 'column'
            },
            title: {
                text: 'Number of items sold per day'
            },
            xAxis: {
                categories: day,
                title: {
                    text: 'Day of week'
                }
            },
            yAxis: {
                min: 0,
                title: {
                    text: 'Number sold per day '
                },
                labels: {
                    overflow: 'justify'
                }
            },
            plotOptions: {
                bar: {
                    dataLabels: {
                        enabled: true
                    }
                }
            },
            legend: {
                enabled: false
            },
            credits: {
                enabled: false
            },
            series: [{
                    data: counter, color: 'orange'
                }]
        });
    };
    ItemsComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-items',
            template: __webpack_require__(/*! ./items.component.html */ "./src/app/items/items.component.html"),
            styles: [__webpack_require__(/*! ./items.component.css */ "./src/app/items/items.component.css")]
        }),
        __metadata("design:paramtypes", [_items_service__WEBPACK_IMPORTED_MODULE_1__["ItemsService"],
            _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"]])
    ], ItemsComponent);
    return ItemsComponent;
}());



/***/ }),

/***/ "./src/app/modifications/modifications.component.css":
/*!***********************************************************!*\
  !*** ./src/app/modifications/modifications.component.css ***!
  \***********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".schema{\n    font-weight: bold\n}\n.jumbotron{\n    text-align: center\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvbW9kaWZpY2F0aW9ucy9tb2RpZmljYXRpb25zLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7SUFDSSxpQkFBaUI7Q0FDcEI7QUFDRDtJQUNJLGtCQUFrQjtDQUNyQiIsImZpbGUiOiJzcmMvYXBwL21vZGlmaWNhdGlvbnMvbW9kaWZpY2F0aW9ucy5jb21wb25lbnQuY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLnNjaGVtYXtcbiAgICBmb250LXdlaWdodDogYm9sZFxufVxuLmp1bWJvdHJvbntcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXJcbn0iXX0= */"

/***/ }),

/***/ "./src/app/modifications/modifications.component.html":
/*!************************************************************!*\
  !*** ./src/app/modifications/modifications.component.html ***!
  \************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"jumbotron jumbotron-fluid\">\n  <div class=\"container\">\n      <h1 class=\"display-4\">Modifications</h1>\n     <p>\n       <b>Modifications MUST be done via the SQL Query Interface. Use the information below to do so.</b>\n       <br><br>\n       This page will provide you with query formats to use on the SQL Query Interface. \n       <br>\n       These query formats will allow you to Insert, Delete, or Update any row in our database.\n       <br><br>\n       For <b>INSERT</b>, you should only be editting the values within VALUES(...). See example for details.\n       <br><br>\n       For <b>UPDATE</b> you can edit any of the values in a row. Take the Update example below and add or remove any fields you want to update.\n       <br><br>\n       If the query is succesful, the SQL Query Interface will print that out. E.g. \"Succesful Insert\".\n       <br>\n       If there is an error with syntax or your statement triggers our Event Condition Actions (ECAs), an error will print out.\n      </p>\n      <p class=\"bars\">\n          <b>Example for Bars:</b>\n          <br>\n          <b>INSERT INTO</b> bars\n          (`barId`,\n          `barName`,\n          `license`,\n          `open`,\n          `close`,\n          `phone`,\n          `address`,\n          `city`,\n          `state`)\n          VALUES\n          (1000, 'exName', 'exLicense', '12:00', '13:00', '123456789', '10 Example St.', 'Trenton', 'NJ');\n          <br>\n          <br>\n          <b>DELETE FROM </b>bars\n          WHERE barId = 10;\n          <br><br>\n          <b>UPDATE</b> bars\nSET\n`barName` = 'exampleName',\n`license` = 'exampleLicense',\nWHERE `barId` = 0;\n        <br>\n        *You can add or remove column names if you wish to change how many columns you modify!*\n\n          \n         <br><br>\n         The statements above can be conducted on any of the tables below as long as they conform to the Relationship Schema.\n         <br>\n         Use this schema to insert, modify, or delete from any of our tables:\n         <br><br>\n      </p>\n         <p class=\"schema\">\n          Relationship Schema \n          <br>\n          drinkers[drinkerId,drinkerName,phone,address,city,state]\n          <br>\n          bars[barId,barName,license,address,city,phone,open,close,state]\n          <br>\n          frequents[barId,drinkerId]\n          <br>\n          items[itemId,itemName,type,price,manufacturer] \n          <br>\n          likes[drinkerId,itemId] \n          <br>\n          sells[barId,itemId,price]\n          <br>\n          transactions[transactionId,drinkerId,billId,itemId,price,barId]\n          <br>\n          bills[billId,tax,total,date,hour] \n          <br>\n          taxRates[state,taxrate]\n          <br><br>\n      </p>\n  </div>\n</div>"

/***/ }),

/***/ "./src/app/modifications/modifications.component.ts":
/*!**********************************************************!*\
  !*** ./src/app/modifications/modifications.component.ts ***!
  \**********************************************************/
/*! exports provided: ModificationsComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ModificationsComponent", function() { return ModificationsComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var ModificationsComponent = /** @class */ (function () {
    function ModificationsComponent() {
    }
    ModificationsComponent.prototype.ngOnInit = function () {
    };
    ModificationsComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-modifications',
            template: __webpack_require__(/*! ./modifications.component.html */ "./src/app/modifications/modifications.component.html"),
            styles: [__webpack_require__(/*! ./modifications.component.css */ "./src/app/modifications/modifications.component.css")]
        }),
        __metadata("design:paramtypes", [])
    ], ModificationsComponent);
    return ModificationsComponent;
}());



/***/ }),

/***/ "./src/app/sqlqueryinterface/interface-details.component.css":
/*!*******************************************************************!*\
  !*** ./src/app/sqlqueryinterface/interface-details.component.css ***!
  \*******************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".querybox{\n    \n        width: 1000px;\n        font-size:14pt;\n        justify-content: center;\n    \n}\n\n.resultbox {\n    width: 1000px;\n        font-size:14pt;\n        justify-content: center;\n}\n\n.buttonholder{\n    text-align: center\n}\n\n.jumbotron{\n    text-align: center\n}\n\n.schema{\n    font-weight: bold\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvc3FscXVlcnlpbnRlcmZhY2UvaW50ZXJmYWNlLWRldGFpbHMuY29tcG9uZW50LmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTs7UUFFUSxjQUFjO1FBQ2QsZUFBZTtRQUNmLHdCQUF3Qjs7Q0FFL0I7O0FBRUQ7SUFDSSxjQUFjO1FBQ1YsZUFBZTtRQUNmLHdCQUF3QjtDQUMvQjs7QUFDRDtJQUNJLGtCQUFrQjtDQUNyQjs7QUFFRDtJQUNJLGtCQUFrQjtDQUNyQjs7QUFFRDtJQUNJLGlCQUFpQjtDQUNwQiIsImZpbGUiOiJzcmMvYXBwL3NxbHF1ZXJ5aW50ZXJmYWNlL2ludGVyZmFjZS1kZXRhaWxzLmNvbXBvbmVudC5jc3MiLCJzb3VyY2VzQ29udGVudCI6WyIucXVlcnlib3h7XG4gICAgXG4gICAgICAgIHdpZHRoOiAxMDAwcHg7XG4gICAgICAgIGZvbnQtc2l6ZToxNHB0O1xuICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgICBcbn1cblxuLnJlc3VsdGJveCB7XG4gICAgd2lkdGg6IDEwMDBweDtcbiAgICAgICAgZm9udC1zaXplOjE0cHQ7XG4gICAgICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xufVxuLmJ1dHRvbmhvbGRlcntcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXJcbn1cblxuLmp1bWJvdHJvbntcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXJcbn1cblxuLnNjaGVtYXtcbiAgICBmb250LXdlaWdodDogYm9sZFxufSJdfQ== */"

/***/ }),

/***/ "./src/app/sqlqueryinterface/interface-details.component.html":
/*!********************************************************************!*\
  !*** ./src/app/sqlqueryinterface/interface-details.component.html ***!
  \********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"jumbotron jumbotron-fluid\">\n  <div class=\"container\">\n      <h1 class=\"display-4\">SQL Query Interface</h1>\n     <p>\n       This interface allows you to execute a query on any of the schemas in our database. \n       <br>\n       Please use the following relationship schema to do so:\n      </p>\n      <p class=\"schema\">\n          Relationship Schema \n          <br>\n          drinkers[drinkerId,drinkerName,phone,address,city,state]\n          <br>\n          bars[barId,barName,license,address,city,phone,open,close,state]\n          <br>\n          frequents[barId,drinkerId]\n          <br>\n          items[itemId,itemName,type,price,manufacturer] \n          <br>\n          likes[drinkerId,itemId] \n          <br>\n          sells[barId,itemId,price]\n          <br>\n          transactions[transactionId,drinkerId,billId,itemId,price,barId]\n          <br>\n          bills[billId,tax,total,date,hour] \n          <br>\n          taxRates[state,taxrate]\n          <br><br>\n          **If you are still unsure of the column names, a simple select query will return the column names.**\n          <br>\n          Example: SELECT * FROM bars;\n      </p>\n  </div>\n</div>\n\n<div class=\"buttonholder\">\n    <form (ngSubmit)=\"onSubmit()\">\n        <input type = \"text\" class=\"querybox\" name=\"query\"[(ngModel)]=\"user.query\" placeholder=\"SELECT * FROM bars;\">\n        <br><br>\n        <button type=\"submit\" class=\"btn btn-primary \">Submit Query</button>\n      </form>\n      <br>\n      <p-table [value]=\"user.results\" sortMode=\"multiple\" sortField=\"price\">\n        <ng-template pTemplate=\"header\">\n        </ng-template>\n        <ng-template pTemplate=\"body\" let-result>\n          <tr>\n            <td>{{ result }}</td>\n          </tr>\n        </ng-template>\n      </p-table>\n</div>\n\n<br><br>"

/***/ }),

/***/ "./src/app/sqlqueryinterface/interface-details.component.ts":
/*!******************************************************************!*\
  !*** ./src/app/sqlqueryinterface/interface-details.component.ts ***!
  \******************************************************************/
/*! exports provided: InterfaceDetailsComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "InterfaceDetailsComponent", function() { return InterfaceDetailsComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _form_service_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../form-service.service */ "./src/app/form-service.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};


var InterfaceDetailsComponent = /** @class */ (function () {
    function InterfaceDetailsComponent(formService) {
        this.formService = formService;
        this.user = {
            query: "",
            results: []
        };
    }
    InterfaceDetailsComponent.prototype.ngOnInit = function () {
    };
    InterfaceDetailsComponent.prototype.onSubmit = function () {
        var _this = this;
        console.log("Sending");
        console.log(this.user.query);
        this.formService.sendQueries(this.user.query).subscribe(function (user) {
        });
        console.log("Receiving");
        this.formService.getResults().subscribe(function (data) {
            console.log(typeof data);
            _this.user.results = [];
            if (typeof data == "string") {
                _this.user.results.push(data);
            }
            else {
                data.forEach(function (val) {
                    _this.user.results.push(JSON.stringify(val));
                });
            }
        });
    };
    InterfaceDetailsComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-interface-details',
            template: __webpack_require__(/*! ./interface-details.component.html */ "./src/app/sqlqueryinterface/interface-details.component.html"),
            styles: [__webpack_require__(/*! ./interface-details.component.css */ "./src/app/sqlqueryinterface/interface-details.component.css")]
        }),
        __metadata("design:paramtypes", [_form_service_service__WEBPACK_IMPORTED_MODULE_1__["FormServiceService"]])
    ], InterfaceDetailsComponent);
    return InterfaceDetailsComponent;
}());



/***/ }),

/***/ "./src/app/welcome/welcome.component.css":
/*!***********************************************!*\
  !*** ./src/app/welcome/welcome.component.css ***!
  \***********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3dlbGNvbWUvd2VsY29tZS5jb21wb25lbnQuY3NzIn0= */"

/***/ }),

/***/ "./src/app/welcome/welcome.component.html":
/*!************************************************!*\
  !*** ./src/app/welcome/welcome.component.html ***!
  \************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"jumbotron jumbotron-fluid\">\n  <div class=\"container\">\n    <h1 class=\"display-4\">Welcomes to Bar Beer Drinker!</h1>\n    <p class=\"lead\">Eshil Patel and Masood Karimi</p>\n  </div>\n</div>\n\n<div class=\"container\">\n\n  <p-table [value]=\"bars\">\n    <ng-template pTemplate=\"header\">\n        <tr>\n          <th>BarId</th>\n          <th>Name</th>\n          <th>License</th>\n          <th>Address</th>\n          <th>City</th>\n          <th>Phone</th>\n        </tr>\n    </ng-template>\n    <ng-template pTemplate=\"body\" let-bar>\n        <tr>\n          <td>\n            <a routerLink=\"/bars/{{ bar.barId }}\">\n              {{ bar.barId }}\n            </a>\n          </td>\n          <td>{{ bar.barName }}</td>\n          <td>{{ bar.license }}</td>\n          <td>{{ bar.address }}</td>\n          <td>{{ bar.city }}</td>\n          <td>{{ bar.phone }}</td>\n        </tr>\n    </ng-template>\n  </p-table>\n</div>\n\n<br><br>"

/***/ }),

/***/ "./src/app/welcome/welcome.component.ts":
/*!**********************************************!*\
  !*** ./src/app/welcome/welcome.component.ts ***!
  \**********************************************/
/*! exports provided: WelcomeComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "WelcomeComponent", function() { return WelcomeComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _bars_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../bars.service */ "./src/app/bars.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};


var WelcomeComponent = /** @class */ (function () {
    function WelcomeComponent(barService) {
        this.barService = barService;
        this.getBars();
    }
    WelcomeComponent.prototype.ngOnInit = function () {
    };
    WelcomeComponent.prototype.getBars = function () {
        var _this = this;
        this.barService.getBars().subscribe(function (data) {
            _this.bars = data;
        }, function (error) {
            alert('Could not retrieve a list of bars');
        });
    };
    WelcomeComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-welcome',
            template: __webpack_require__(/*! ./welcome.component.html */ "./src/app/welcome/welcome.component.html"),
            styles: [__webpack_require__(/*! ./welcome.component.css */ "./src/app/welcome/welcome.component.css")]
        }),
        __metadata("design:paramtypes", [_bars_service__WEBPACK_IMPORTED_MODULE_1__["BarsService"]])
    ], WelcomeComponent);
    return WelcomeComponent;
}());



/***/ }),

/***/ "./src/environments/environment.ts":
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/*! exports provided: environment */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "environment", function() { return environment; });
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build ---prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
var environment = {
    production: false
};
/*
 * In development mode, for easier debugging, you can ignore zone related error
 * stack frames such as `zone.run`/`zoneDelegate.invokeTask` by importing the
 * below file. Don't forget to comment it out in production mode
 * because it will have a performance impact when errors are thrown
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ "./src/main.ts":
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser-dynamic */ "./node_modules/@angular/platform-browser-dynamic/fesm5/platform-browser-dynamic.js");
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app/app.module */ "./src/app/app.module.ts");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./environments/environment */ "./src/environments/environment.ts");




if (_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].production) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["enableProdMode"])();
}
Object(_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__["platformBrowserDynamic"])().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_2__["AppModule"])
    .catch(function (err) { return console.log(err); });


/***/ }),

/***/ 0:
/*!***************************!*\
  !*** multi ./src/main.ts ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! /Users/masoodkarimi/Documents/Bar_Beer_Drinker_Teacher_Version/bar-beer-drinker-ui/src/main.ts */"./src/main.ts");


/***/ })

},[[0,"runtime","vendor"]]]);
//# sourceMappingURL=main.js.map