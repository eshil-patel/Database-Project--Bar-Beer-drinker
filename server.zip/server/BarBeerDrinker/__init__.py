from flask import Flask, render_template
from flask import jsonify
from flask import make_response
from flask import request
import json

from BarBeerDrinker import database

app = Flask(__name__)

query = ""

@app.route('/')
def hello_world():
    return render_template('index.html')

@app.route('/api/form-example', methods=['GET', 'POST'])
def form_example():
    try:
        global query
        if request.method == 'POST': #this block is only entered when the form is submitted
            query = request.data
            return  query
        results = database.getResults(query)
        if (results == []):
            return jsonify("No Results")
        return jsonify(results)
    except Exception as e:
        if ("does not return rows" in str(e)):
            if ("insert" in str(query).lower()):
                return jsonify("Succesful Insertion.") 
            if ("delete" in str(query).lower()):
                return jsonify("Succesful Deletion.") 
            if ("update" in str(query).lower()):
                return jsonify("Succesful Update.") 
            return jsonify(e)
        x = str(e[0]).split(')')[1]
        a = x.split('u"')
        if (len(a) > 1):
            x = a[0] + '"' + a[1]
        a = x.split("u\'")
        if (len(a) > 1):
            x = a[0] + '\'' + a[1]
        x = 'Error Code: ' + x.split('(')[1]
        return jsonify(x)

@app.route('/api/bar', methods=["GET"])
def get_bars():
    return jsonify(database.get_bars())


@app.route("/api/bar/<barId>", methods=["GET"])
def find_bar(barId):
    try:
        if barId is None:
            raise ValueError("Bar is not specified.")
        bar = database.find_bar(barId)
        if bar is None:
            return make_response("No bar found with the given name.", 404)
        return jsonify(bar)
    except ValueError as e:
        return make_response(str(e), 400)
    except Exception as e:
        return make_response(str(e), 500)


@app.route("/api/beers_cheaper_than", methods=["POST"])
def find_beers_cheaper_than():
    body = json.loads(request.data)
    max_price = body['maxPrice']
    return jsonify(database.filter_beers(max_price))


@app.route('/firstname',methods=['GET', 'POST'])
def result():
      result = request.form
      print("Got resultss")
      return jsonify(result)

@app.route('/api/menu/<barId>', methods=['GET'])
def get_menu(barId):
    try:
        if barId is None:
            raise ValueError('Bar is not specified.')
        bar = database.find_bar(barId)
        if bar is None:
            return make_response("No bar found with the given id.", 404)
        return jsonify(database.get_bar_menu(barId))
    except ValueError as e:
        return make_response(str(e), 400)
    except Exception as e:
        return make_response(str(e), 500)


@app.route("/api/bar-cities", methods=["GET"])
def get_bar_cities():
    try:
        return jsonify(database.get_bar_cities())
    except Exception as e:
        return make_response(str(e), 500)

@app.route("/api/top-drinkers/<barId>", methods=["GET"])
def getTopDrinkers(barId):
    try:
        if barId is None:
            raise ValueError('Bar is not specified.')
        bar = database.find_bar(barId)
        if bar is None:
            return make_response("No bar found with the given id.", 404)
        return jsonify(database.find_top_drinkers(barId))
    except ValueError as e:
        return make_response(str(e), 400)
    except Exception as e:
        return make_response(str(e), 500)

@app.route("/api/top-purchases/<barId>", methods=["GET"])
def getTopPurchases(barId):
    try:
        if barId is None:
            raise ValueError('Bar is not specified.')
        bar = database.find_bar(barId)
        if bar is None:
            return make_response("No bar found with the given id.", 404)
        return jsonify(database.find_top_purchases(barId))
    except ValueError as e:
        return make_response(str(e), 400)
    except Exception as e:
        return make_response(str(e), 500)

@app.route("/api/sale-dates/<barId>", methods=["GET"])
def getSaleDates(barId):
    try:
        if barId is None:
            raise ValueError('Bar is not specified.')
        bar = database.find_bar(barId)
        if bar is None:
            return make_response("No bar found with the given id.", 404)
        return jsonify(database.find_sale_dates(barId))
    except ValueError as e:
        return make_response(str(e), 400)
    except Exception as e:
        return make_response(str(e), 500)

@app.route("/api/sale-hours/<barId>", methods=["GET"])
def getSaleHours(barId):
    try:
        if barId is None:
            raise ValueError('Bar is not specified.')
        bar = database.find_bar(barId)
        if bar is None:
            return make_response("No bar found with the given id.", 404)
        return jsonify(database.find_sale_hours(barId))
    except ValueError as e:
        return make_response(str(e), 400)
    except Exception as e:
        return make_response(str(e), 500)

@app.route("/api/top-manufacturers/<barId>", methods=["GET"])
def getTopManufacturers(barId):
    try:
        if barId is None:
            raise ValueError('Bar is not specified.')
        bar = database.find_bar(barId)
        if bar is None:
            return make_response("No bar found with the given id.", 404)
        return jsonify(database.find_top_manufacturers(barId))
    except ValueError as e:
        return make_response(str(e), 400)
    except Exception as e:
        return make_response(str(e), 500)

@app.route("/api/items", methods=["GET"])
def get_beers():
    print("Getting beers")
    try:
        return jsonify(database.get_beers())
    except Exception as e:
        return make_response(str(e), 500)


@app.route("/api/beer-manufacturer", methods=["GET"])
def get_beer_manufacturers():
    print("abcd")
    try:
        return jsonify(database.get_beer_manufacturers(None))
    except Exception as e:
        print("Exception")
        return make_response(str(e), 500)


@app.route("/api/beer-manufacturer/<itemId>", methods=["GET"])
def get_manufacturers_making(beer):
    print("This one")
    try:
        return jsonify(database.get_beer_manufacturers(itemId))
    except Exception as e:
        return make_response(str(e), 500)


@app.route("/api/likes", methods=["GET"])
def get_likes():
    try:
        drinker = request.args.get("drinker")
        if drinker is None:
            raise ValueError("Drinker is not specified.")
        return jsonify(database.get_likes(drinker))
    except Exception as e:
        return make_response(str(e), 500)


@app.route("/api/drinker", methods=["GET"])
def get_drinkers():
    try:
        return jsonify(database.get_drinkers())
    except Exception as e:
        return make_response(str(e), 500)


@app.route("/api/drinker/<drinkerId>", methods=["GET"])
def get_drinker(drinkerId):
    try:
        if drinkerId is None:
            raise ValueError("Drinker is not specified.")
        return jsonify(database.get_drinker_info(drinkerId))
    except ValueError as e:
        return make_response(str(e), 400)
    except Exception as e:
        return make_response(str(e), 500)


@app.route('/api/bars-selling/<items>', methods=['GET'])
def find_bars_selling(beer):
    print("This..")
    try:
        if beer is None:
            raise ValueError('Beer not specified')
        return jsonify(database.get_bars_selling(beer))
    except ValueError as e:
        return make_response(str(e), 400)
    except Exception as e:
        return make_response(str(e), 500)


@app.route('/api/frequents-data', methods=['GET'])
def get_bar_frequent_counts():
    try:
        return jsonify(database.get_bar_frequent_counts())
    except Exception as e:
        return make_response(str(e), 500)

@app.route('/api/trans/<drinkerId>', methods=['GET'])
def get_trans_info(drinkerId):
    try: 
        if drinkerId is None:
            raise ValueError('Drinker not specified')
        return jsonify(database.get_trans_info(drinkerId))
    except ValueError as e:
        return make_response(str(e), 400)
    except Exception as e:
        return make_response(str(e), 500)
@app.route('/api/transcount/<drinkerId>',methods=['GET'])
def get_trans_count(drinkerId):
    try: 
        if drinkerId is None:
            raise ValueError('Drinker not specified')
        return jsonify(database.get_trans_count(drinkerId))
    except ValueError as e:
        return make_response(str(e), 500)

@app.route('/api/items/<itemId>',methods=['GET'])
def get_item_pop(itemId):
    try:
        if itemId is None:
             raise ValueError('Item not specified')
        return jsonify(database.get_item_pop(itemId))
    except ValueError as e:
        return make_response(str(e), 500)

@app.route('/api/itemdrinker/<itemId>',methods=['GET'])
def get_item_drinker_pop(itemId):
    try:
        if itemId is None:
            raise ValueError('Item not specified')
        return jsonify(database.get_item_drinker_pop(itemId))
    except ValueError as e:
        return make_response(str(e), 500)

@app.route('/api/itemdays/<itemId>',methods=['GET'])
def get_item_time_dist(itemId):
    try:
        if itemId is None:
            raise ValueError('Item not specified')
        return jsonify(database.get_item_time_dist(itemId))
    except ValueError as e:
        return make_response(str(e), 500)

@app.route('/api/itemtime/<itemId>',methods=["GET"])
def get_item_dist(itemId):
    try:
        if itemId is None:
            raise ValueError('Item not specified')
        return jsonify(database.get_item_dist(itemId))
    except ValueError as e:
        return make_response(str(e), 500)

@app.route('/api/drinkermonth/<drinkerId>',methods=["GET"])
def get_drinker_month_spend(drinkerId):
    try:
        if drinkerId is None:
            raise ValueError('Drinker not specified')
        return jsonify(database.drinker_spend_month(drinkerId))
    except ValueError as e:
        return make_response(str(e), 500)

@app.route('/api/drinkerday/<drinkerId>',methods=["GET"])
def get_drinker_day_spend(drinkerId):
    try:
        if drinkerId is None:
            raise ValueError('Drinker not specified')
        return jsonify(database.drinker_spend_day(drinkerId))
    except ValueError as e:
        return make_response(str(e),500)

@app.route('/api/drinkerweek/<drinkerId>',methods=["GET"])
def get_drinker_week_spend(drinkerId):
    try:
        if drinkerId is None:
            raise ValueError("Drinker not specified")
        return jsonify(database.drinker_spend_week(drinkerId))
    except ValueError as e:
        return make_response(str(e),500)

@app.route('/api/getiteminfo/<itemId>',methods=["GET"])
def get_item_info(itemId):
    try:
        if itemId is None:
            raise ValueError("Item not specified")
        return jsonify(database.get_items(itemId))
    except ValueError as e:
        return make_response(str(e),500)